import type { GlobalConfig } from 'payload'

export const ProjectsPage: GlobalConfig = {
  slug: 'projects-page',
  admin: {
    description: 'Page-level content for the Projects page: hero copy, empty-state message, detail-page section labels, and the closing CTA.',
  },
  access: {
    read: () => true, // public — the frontend fetches this without auth
  },
  fields: [
    {
      name: 'projectsHero',
      type: 'group',
      label: 'Hero',
      fields: [
        {
          name: 'eyebrow',
          type: 'text',
          required: true,
        },
        {
          name: 'headlineLine1',
          type: 'text',
          required: true,
        },
        {
          name: 'headlineLine2',
          type: 'text',
          required: true,
        },
        {
          name: 'subline',
          type: 'textarea',
          required: true,
        },
      ],
    },
    {
      name: 'projectsEmptyMessage',
      type: 'text',
      required: true,
      admin: {
        description: 'Shown when a category filter matches no projects.',
      },
    },
    {
      name: 'projectDetailLabels',
      type: 'group',
      label: 'Detail Page Section Labels',
      fields: [
        { name: 'overviewHeading', type: 'text', required: true },
        { name: 'servicesHeading', type: 'text', required: true },
        { name: 'specsHeading', type: 'text', required: true },
        { name: 'galleryHeading', type: 'text', required: true },
        { name: 'relatedHeading', type: 'text', required: true },
        { name: 'ctaLabel', type: 'text', required: true },
      ],
    },
    {
      name: 'projectsCTA',
      type: 'group',
      label: 'Closing CTA',
      fields: [
        { name: 'eyebrow', type: 'text', required: true },
        { name: 'heading', type: 'text', required: true },
        { name: 'subline', type: 'textarea', required: true },
        { name: 'primaryBtnLabel', type: 'text', required: true },
        {
          name: 'primaryBtnLink',
          type: 'text',
          required: true,
          admin: { description: 'Internal path, e.g. /contact' },
        },
        { name: 'secondaryBtnLabel', type: 'text', required: true },
        {
          name: 'secondaryBtnLink',
          type: 'text',
          required: true,
          admin: { description: 'Internal path, e.g. /services' },
        },
      ],
    },
  ],
}