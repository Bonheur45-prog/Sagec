import type { GlobalConfig } from 'payload'

export const TestimonialsPage: GlobalConfig = {
  slug: 'testimonials-page',
  admin: {
    description: 'Page-level hero copy for the Testimonials page.',
  },
  access: {
    read: () => true,
  },
  fields: [
    {
      name: 'eyebrow',
      type: 'text',
      required: true,
    },
    {
      name: 'headlineLine1',
      type: 'text',
      required: true,
    },
    {
      name: 'headlineLine2',
      type: 'text',
      required: true,
    },
    {
      name: 'subline',
      type: 'textarea',
      required: true,
    },
  ],
}